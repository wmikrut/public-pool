export enum eResponseMethod {
    SET_DIFFICULTY = 'mining.set_difficulty',
    MINING_NOTIFY = 'mining.notify',
}